## Algoritmos 2 -- Taller de listas enlazadas

### Consigna

1) Implementar una lista doblemente enlazada de enteros, es decir, que cada nodo esté conectado con el siguiente y con el anterior (a diferencia de la lista simple).

* Elegir una representación y agregarla a la parte privada de la clase Lista
* Implementar todos los métodos de Lista sobre la estructura elegida

### Instrucciones

* Bajarse el zip con la consigna a una carpeta
* Importar el proyecto en CLion
* Codear!
* Los archivos a entregar son Lista.h y Lista.cpp
