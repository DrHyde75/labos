#include "gtest-1.8.1/gtest.h"
#include "../src/Libreta.h"
#include "../src/Truco.h"
#include <map>
#include <cmath>

using namespace std;

// Ejercicio 4
TEST(Aritmetica, suma) {
    EXPECT_EQ(15+7, 22);
}

// Ejercicio 5
TEST(Aritmetica, potencia) {
    EXPECT_EQ(pow(10,2), 100);
}

// Ejercicio 6
TEST(Aritmetica, ṕotencia_general) {
    for(int n = -5; n <= 5; n++){
        if (n != 0 ) {
            int fun = pow(n, 2);
            int mul = n * n;
            EXPECT_EQ(fun, mul);
        }
    }
}

// Ejercicio 7
TEST(Map, obtener){
    map<int,int> dic;
    int clave = 1;
    int significado = 10;
    dic[clave] = significado;
    EXPECT_EQ(dic[clave], significado);
}

// Ejercicio 8
TEST(Map, definir){
    map<int,int> dic;
    int clave;
    int significado;
    EXPECT_TRUE(dic.count(clave) == 0);

    dic[clave] = significado;
    EXPECT_TRUE(dic.count(clave) == 1);
}

// Ejercicio 9
TEST(Truco, inicio){
    Truco();
    Truco tru;
    EXPECT_TRUE(tru.puntaje_j1() == 0 && tru.puntaje_j2() == 0);
}

// Ejercicio 10
TEST(Truco, buenas){
    Truco tru;
    EXPECT_FALSE(tru.buenas(1));
    for (int i = 0; i <= 15; i++){
        tru.sumar_punto(1);
    }
    EXPECT_FALSE(tru.buenas(1));

    tru.sumar_punto(1);
    EXPECT_TRUE(tru.buenas(1));

    tru.sumar_punto(1);
    tru.sumar_punto(1);
    EXPECT_TRUE(tru.buenas(1));

}