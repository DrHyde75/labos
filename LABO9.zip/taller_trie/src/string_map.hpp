template <typename T>
string_map<T>::string_map(): raiz(nullptr){
    // COMPLETAR
}

template <typename T>
string_map<T>::string_map(const string_map<T>& aCopiar) : string_map() { *this = aCopiar; } // Provisto por la catedra: utiliza el operador asignacion para realizar la copia.

template <typename T>
string_map<T>& string_map<T>::operator=(const string_map<T>& d) {
    // COMPLETAR
}

template <typename T>
string_map<T>::~string_map(){
    // COMPLETAR
}

template <typename T>
T& string_map<T>::operator[](const string& clave){
    // COMPLETAR
}


template <typename T>
int string_map<T>::count(const string& clave) const{
    int res = 1;
    if (raiz == nullptr){
        res = 0;
    }
    else {
        Nodo* actual = raiz;
        string pal = clave;
        for(int i = 0; i < pal.size();i++){
            if ((actual->siguientes)[pal[i]] != nullptr){
                actual = actual->siguientes[pal[i]];
            }
            else{
                res = 0;
            }
        }
    }
    return res;
}

template <typename T>
const T& string_map<T>::at(const string& clave) const {
    Nodo* actual = raiz;
    string pal = clave;
    for(int i = 0; i < pal.size();i++){
        actual = actual->siguientes[pal[i]];
    }
    return *(actual->definicion);
}

template <typename T>
T& string_map<T>::at(const string& clave) {
    Nodo* actual = raiz;
    string pal = clave;
    for(int i = 0; i < pal.size();i++){
        actual = actual->siguientes[pal[i]];
    }
    return *(actual->definicion);
}

template <typename T>
void string_map<T>::erase(const string& clave) {
    // COMPLETAR
}

template <typename T>
int string_map<T>::size() const{
    // COMPLETAR
}

template <typename T>
bool string_map<T>::empty() const{
    bool res = true;
    if (raiz == nullptr){
        res = true;
    }
    else {
        vector<Nodo*> ps = raiz->siguientes;
        for (int i = 0; i < 256; i++) {
            if (ps[i] != nullptr) {
                res = false;
            }
        }
    }
    return res;
}

template <typename T>
void string_map<T>::insert(const pair<string,T>& value_type){
    if (raiz == nullptr){
        string pal = value_type.first;
        raiz = new Nodo();
        Nodo* actual = raiz;
        for(int i = 0; i < pal.size();i++){
            (actual->siguientes)[pal[i]] = new Nodo();
            actual = (actual->siguientes)[pal[i]];
        }
    }
    else {
        Nodo* actual = raiz;
        string pal = value_type.first;
        for(int i = 0; i < pal.size();i++){
            if (actual->siguientes[pal[i]] != nullptr){
                actual = actual->siguientes[pal[i]];
            }
            else{
                (actual->siguientes)[pal[i]] = new Nodo();
                actual = (actual->siguientes)[pal[i]];
            }
        }
    }

}