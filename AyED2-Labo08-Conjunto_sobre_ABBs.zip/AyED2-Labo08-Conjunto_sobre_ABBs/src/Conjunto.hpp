
template <class T>
Conjunto<T>::Conjunto() : _raiz(nullptr){
    // Completar
}

template <class T>
Conjunto<T>::~Conjunto() { 
    // Completar
}

template <class T>
bool Conjunto<T>::pertenece(const T& clave) const {
    Nodo* actual = _raiz;
    if (actual == nullptr){
        return false;
    }
    else {
        while (actual != nullptr && actual->valor != clave) {
            if (clave < actual->valor) {
                actual = actual->izq;
            } else {
                actual = actual->der;
            }
        }
        return actual != nullptr;
    }
}

template <class T>
void Conjunto<T>::insertar(const T& clave) {

    Nodo* actual = _raiz;
    Nodo* nuevo = new Nodo(clave);
    if (actual == nullptr){
        _raiz = new Nodo(clave);
    }
    else {

        while (actual->der != nullptr && actual->izq != nullptr) {
            if (actual->izq != nullptr && clave < actual->valor) {
                actual = actual->izq;
            } else if (actual->der != nullptr) {
                actual = actual->der;
            }
        }
        if (clave < actual->valor) {
            actual->izq = nuevo;
        } else {
            actual->der = nuevo;
        }
    }

}

template <class T>
void Conjunto<T>::remover(const T& clave) {

    Nodo *actual = _raiz;
    Nodo *padre = _raiz;
    if (actual == _raiz) {
        if (clave < actual->valor) {
            actual = actual->izq;
        } else {
            actual = actual->der;
        }
    }
    while (actual != nullptr && actual->valor != clave) {
        if (clave < actual->valor) {
            actual = actual->izq;
            padre = padre->izq;
        } else {
            actual = actual->der;
            padre = padre->der;
        }
    }
    if (actual->der == nullptr && actual->izq == nullptr) {
        padre->izq = nullptr;
        padre->der = nullptr;
    } else if (actual->der == nullptr && actual->izq != nullptr) {
        padre->izq = actual->izq;
    }
    else if (actual->izq == nullptr && actual->der != nullptr){
        padre->izq = actual->izq;
    }
    else{
        if (padre->der == actual){
        padre->der = predecesorInmediato(actual);
        (padre->der)->der = actual->der;
    }
        else {
            padre->izq = predecesorInmediato(actual);
            (padre->izq)->der = actual->der;
        }
    }

}

template <class T>
const T& Conjunto<T>::siguiente(const T& clave) {
    assert(false);
}

template <class T>
const T& Conjunto<T>::minimo() const {
    assert(false);
}

template <class T>
const T& Conjunto<T>::maximo() const {
    assert(false);
}

template <class T>
typename Conjunto<T>::Nodo* Conjunto<T>::predecesorInmediato(Nodo *elem) {
    Nodo* actual = elem;
    actual = actual->izq;
    while (actual->der != nullptr){
        actual = actual->der;
    }
    return actual;
}

template <class T>
unsigned int Conjunto<T>::cardinal() const {


    return 0;
}

template <class T>
void Conjunto<T>::mostrar(std::ostream&) const {
    assert(false);
}

