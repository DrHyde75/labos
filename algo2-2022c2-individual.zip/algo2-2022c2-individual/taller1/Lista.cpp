#include "Lista.h"

Lista::Lista() : prim(nullptr), ult(nullptr){
    // Completar

}

Lista::Lista(const Lista& l) : Lista() {
    //Inicializa una lista vacía y luego utiliza operator= para no duplicar el código de la copia de una lista.
    *this = l;
}

Lista::~Lista() {
    // Completar
    destruirNodos();
}

Lista& Lista::operator=(const Lista& aCopiar) {
    // Completar
    destruirNodos();
    copiarNodos(aCopiar);
    return *this;
}

void Lista::agregarAdelante(const int& elem) {
    // Completar
    Nodo* nuevo = new Nodo(elem,nullptr,nullptr);
    if (prim == nullptr){
        prim = nuevo;
        return;
    }
    Nodo* actual = prim;
    while (actual->ant != nullptr){
        actual = actual->ant;
    }
    actual->ant = nuevo;
    nuevo->sig = actual;

}

void Lista::agregarAtras(const int& elem) {
    // Completar
    Nodo* nuevo = new Nodo(elem,nullptr,nullptr);
    if (prim == nullptr){
        prim = nuevo;
        return;
    }
    Nodo* actual = prim;
    while (actual->sig != nullptr){
        actual = actual->sig;
    }
    actual->sig = nuevo;
    nuevo->ant = actual;
}

void Lista::eliminar(Nat i) {
    // Completar
    Nodo *actual = prim;
    while (actual->ant != nullptr) {
        actual = actual->ant;
    }
    if (i == 0 && longitud() == 1) {
        prim = nullptr;
        ult = nullptr;
    }
    else if (i == 0){
        prim = prim->sig;
        (actual->sig)->ant = nullptr;
    }
    else{

        for (int j = 0; j <= i; j++) {
            if (j == i) {
                if (actual->ant == nullptr) {
                    (actual->sig)->ant = nullptr;
                } else if (actual->sig == nullptr) {
                    (actual->ant)->sig = nullptr;
                } else {
                    (actual->ant)->sig = actual->sig;
                    (actual->sig)->ant = actual->ant;
                }
            } else {
                actual = actual->sig;

            }
        }
    }
    delete actual;
}

int Lista::longitud() const {
    // Completar
    Nodo* actual = prim;
    if (actual == nullptr){
        return 0;
    }
    while (actual->ant != nullptr){
        actual = actual->ant;
    }

    int cont = 0;
    while (actual != nullptr){
        cont++;
        actual = actual->sig;
    }
    return cont;
}

const int& Lista::iesimo(Nat i) const {
    // Completar
    Nodo* actual = prim;

    while (actual->ant != nullptr){
        actual = actual->ant;
    }

    for (int j = 0; j < i; j++){
        actual = actual->sig;
    }
    return actual->valor;
}

int& Lista::iesimo(Nat i) {
    // Completar (hint: es igual a la anterior...)
    Nodo* actual = prim;

    while (actual->ant != nullptr){
        actual = actual->ant;
    }

    for (int j = 0; j < i; j++){
        actual = actual->sig;
    }
    return actual->valor;
}

void Lista::mostrar(ostream& o) {
    // Completar
}

void Lista::destruirNodos() {
    Nodo* actual = prim;
    if (actual == nullptr){
        return;
    }
    while (actual->ant != nullptr){
        actual = actual->ant;
    }
    while (actual != nullptr){
        Nodo* siguiente = actual->sig;
        delete actual;
        actual = siguiente;
    }
    prim = nullptr;
}

void Lista::copiarNodos(const Lista &aCopiar) {
    Nodo *actual = aCopiar.prim;
    while (actual != nullptr) {
        agregarAtras(actual->valor);
        actual = actual->sig;
    }

}