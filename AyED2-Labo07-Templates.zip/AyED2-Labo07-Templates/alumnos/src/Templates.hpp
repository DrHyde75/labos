#include "vector"

template<class T>
T cuadrado(T x){
    return x * x;
}

template<class Contenedor, class Elemento>
bool contiene(Contenedor con, Elemento elem) {
    bool res;
    for (int i = 0; i < con.size(); i++) {
        if (con[i] == elem) {
            res = true;
        }
        return res;
    }
}

template<class Contenedor>
bool esPrefijo(Contenedor a, Contenedor b){
    bool res = true;
    if (a.size() > b.size()){
        return false;
    }
    for (int i = 0; i < a.size();i++){
        if (a[i] != b[i]){
            res = false;
        }
    }
    return res;
}

template<class Contenedor>
int maximo(Contenedor a){
    int max = a[0];
    for (int i = 0; i < a.size();i++){
        if (a[i] > max){
            max = a[i];
        }
    }
    return max;
}