#ifndef ALGO2_LABO_CLASE5_ALGORITMOS_H
#define ALGO2_LABO_CLASE5_ALGORITMOS_H

#include <utility>
#include <iterator>
#include <vector>
#include <iterator>

// Completar con las funciones del enunciado
template<class Contenedor>

typename Contenedor::value_type minimo(const Contenedor &c) {
    typename Contenedor::const_iterator it = c.begin();
    typename Contenedor::const_iterator min = c.begin();
    while (it != c.end()) {
        if (*it < *min) {
            min = it;
        }
        ++it;
    }
    return *min;
};

template<class Contenedor>

typename Contenedor::value_type promedio(const Contenedor &c) {
    typename Contenedor::const_iterator it = c.begin();
    typename Contenedor::value_type sum = 0;
    typename Contenedor::value_type n = 0;
    while (it != c.end()) {
        sum = sum + *it;
        n++;
        ++it;
    }
    return sum / n;
};


template<class Iterator>
typename Iterator::value_type minimoIter(const Iterator &desde, const Iterator &hasta) {
    Iterator min = desde;
    Iterator in = desde;
    while (in != hasta) {
        if (*in < *min) {
            min = in;
        }
        ++in;
    }
    return *min;
};

template<class Iterator>
typename Iterator::value_type promedioIter(const Iterator &desde, const Iterator &hasta) {
    typename Iterator::value_type sum = 0;
    typename Iterator::value_type n = 0;
    Iterator in = desde;
    while (in != hasta) {
        sum = sum + *in;
        n++;
        ++in;
    }
    return sum / n;

};

template<class Contenedor>
void filtrar(Contenedor &c, const typename Contenedor::value_type &elem) {
    typename Contenedor::const_iterator it = c.begin();
    while (it != c.end()) {
        if (*it == elem) {
            it = c.erase(it);
        } else {
            it++;
        }
    }
};

template<class Contenedor>
bool ordenado(Contenedor &c) {
    bool res = true;
    typename Contenedor::const_iterator it = c.begin();
    typename Contenedor::const_iterator it1 = c.begin();
    ++it1;
    while (it1 != c.end() && it != c.end() && res) {
        if (*it >= *it1) {
            res = false;
        }
        ++it;
        ++it1;
    }
    return res;
};

template<class Contenedor>
std::pair<Contenedor, Contenedor>
split(const Contenedor & c,
      const typename Contenedor::value_type& elem) {
    typename Contenedor::const_iterator it = c.begin();
    Contenedor may;
    Contenedor men;

    while (it != c.end()) {
        if (*it < elem) {
            men.insert(men.end(), *it);

        }
        else {
            may.insert(may.end(), *it);
        }
        ++it;
    }
    return make_pair(men,may);

}

#endif //ALGO2_LABO_CLASE5_ALGORITMOS_H
